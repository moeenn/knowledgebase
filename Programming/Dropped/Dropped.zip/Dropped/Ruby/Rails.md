```bash
# install package globally
$ gem install rails

# creating a new project
$ rails new <project-name>

# starting the server
$ rails server
```