
Dependency injection framework
https://pypi.org/project/injector/


AI Face recognition attendance system
https://www.youtube.com/watch?v=sz25xxF_AVE&list=WL&index=12&t=1s
