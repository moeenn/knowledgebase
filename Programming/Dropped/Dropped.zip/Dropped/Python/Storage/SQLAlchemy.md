
#### Installation

```bash
pip install sqlalchemy psycopg2-binary
```


