
```bash
# setting up a new project (scala3)
$ sbt new scala/scala3.g8

# setting up a new project (scala2)
$ sbt new scala/hello-world.g8

# run project and exit
$ sbt run

# start sbt shell and keep jvm alive
$ sbt
```

```bash
# generate project incremental build and run
sbt:project> run
```